const config = require("./config/app.config");
const path = require("path");
const express = require("express");
const favicon = require("serve-favicon");
var accesslogger = require("./lib/log/accesslogger.js");
var systemlogger = require("./lib/log/systemlogger.js");
var app = express();

// Static resource rooting.
app.use(favicon(path.join(__dirname, "/public", "/favicon.ico")));
app.use("/public", express.static(path.join(__dirname, "/public")));

// Set access log.
app.use(accesslogger());

// Dynamic resource rooting.
app.use("/", require("./routes/index.js"));

// Set system log.
app.use(systemlogger());

app.listen(config.PORT);
