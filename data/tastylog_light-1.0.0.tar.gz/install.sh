#!/bin/bash
CWD="$(cd $(dirname $0); pwd)"
cd ${CWD}

# ---------------------------------
# Create user/group
# ---------------------------------
userdel -r app-user
groupdel app-group
groupadd -g 1001 app-group
useradd -u 1001 -g 1001 app-user


# ---------------------------------
# Install middlewares.
# ---------------------------------

# Install Node.js
curl -sL https://rpm.nodesource.com/setup_12.x | bash -
yum install -y nodejs

# Install jq
curl -o /usr/local/bin/jq -L https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64
chmod +x /usr/local/bin/jq


# ---------------------------------
# Install application config file.
# ---------------------------------
cp params /etc/
chmod +x /etc/params


# ---------------------------------
# Install tastylog.service
# ---------------------------------
APP_NAME="tastylog"
APP_SERVICE="/etc/systemd/system/${APP_NAME}.service"

# Install application service
rm -rf "${APP_SERVICE}"
cp "${APP_SERVICE##*/}" "${APP_SERVICE}"
chmod +x "${APP_SERVICE}"
systemctl daemon-reload


# ---------------------------------
# Install tastylog application
# ---------------------------------
# Install application
cp -r ./${APP_NAME} /opt/
chown -R app-user.app-group /opt/${APP_NAME}

# Start service
systemctl enable ${APP_NAME}
systemctl start ${APP_NAME}
